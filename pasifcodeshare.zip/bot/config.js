module.exports = {
  token: "OTMxODIzNzU0NTAwMjU5ODUw.YeKCfw.X4OtXjqNX2CsdygS9yQiZBAV3-A",
  prefix: "logg",
  sahip: "",
  logKanal: "919639604078972968"
}