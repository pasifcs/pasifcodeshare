const Discord = require("discord.js")  
const client = new Discord.Client();    
const config = require("./config.js")  
const fs = require("fs");  
require('./util/Loader.js')(client); 

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();

client.login(config.token)