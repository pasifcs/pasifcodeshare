const Aoijs = require("../models/aoijs-codes");
const Html = require("../models/html-codes");
const Discordjs = require("../models/discordjs-codes");
const config = require('../config')
const Lua = require("../models/lua-codes")
const Users = require("../models/users")

var main_get = (req, res) => {
  if(!req.session.userId){
  res.render("anasayfa", {title: config.mainTitle});
  }else{
    res.redirect("/dashboard")
  }
};

var kurallar = (req,res) => {
  res.render('site/kurallar', {title: config.kurallarTitle})
}

var iletisim = (req,res) => {
  Users.find({rank: "Kurucu"}, function(err,kurucu){
    Users.find({rank: "Yetkili"}, function(err,yetkili){
      Users.find({rank: "Moderatör"}, function(err,mod){
res.render("site/iletisim", {title: config.iletisimTitle, kurucu: kurucu, yetkili: yetkili, mod: mod})
  })
})
})
}

// codes
var aoijs_codes = (req,res) => {
  if(req.session.userId){
  Aoijs.find({onay: true})
  .then(result => { res.render('site/aoijs-codes', {aois: result, title: config.AojsCodesTitle})
  })
  }else{
res.redirect('/login')
    }
}

var html_codes = (req,res) => {
  if(req.session.userId){
  Html.find({onay: true})
  .then(result => { res.render('site/html-codes', {htmls: result, title: config.HtmlCodesTitle})
  })
  }else{
    res.redirect('/login')
  }
}

var discordjs_codes = (req,res) =>{
  if(req.session.userId){
  Discordjs.find({onay: true})
  .then(result => { res.render('site/discordjs-codes', {discords: result, title: config.DiscordjsCodesTitle})
  })
  }else{
    res.redirect('/login')
  }
}

var lua_codes = (req,res) =>{
  if(req.session.userId){
  Lua.find({onay: true})
  .then(result => { res.render('site/lua-codes', {luas: result, title: config.LuaCodesTitle})
  })
  }else{
    res.redirect('/login')
  }
}


//add
var aoi_add = (req, res) => {
  res.render("code-add/aoijs", {title: config.AoijsCodeAddTitle, aoijsAddError: req.flash("aoijsAddError")});
};

var html_add = (req, res) => {
  res.render("code-add/html", {title: config.HtmlCodeAddTitle, htmlAddError: req.flash("htmlAddError")});
};
var discord_add = (req, res) => {
  res.render("code-add/discordjs", {title: config.DiscordjsCodeAddTitle, discordjsAddError: req.flash("discordjsAddError")});
};
var lua_add = (req, res) => {
  res.render("code-add/lua", {title: config.LuaCodeAddTitle, luaAddError: req.flash("LuaAddError")});
};

var search = function(req,res){
Aoijs.find({title: req.body.search}, function(err,aoijs){
  Discordjs.find({title: req.body.search}, function(err,djs){
    Html.find({title: req.body.search}, function(err,html){
      Lua.find({title: req.body.search}, function(err,lua){
        Users.find({username: req.body.search}, function(err,user){     res.render("site/search", {title: config.searchTitle, aoijs: aoijs, djs:djs, html:html, lua:lua, user: user})  
    })
})
})
})
})
}

var user = (req,res) => {
if(req.session.userId){
let userId = req.params.userId;
  Users.findById(userId, function(err,user){
let username = user.username;    
 Aoijs.find({sahip: username}, function(err,aoijs){
  Discordjs.find({sahip: username}, function(err,djs){
    Html.find({sahip: username}, function(err,html){
      Lua.find({sahip: username}, function(err,lua){                
res.render("site/user", {title: config.userTitle, user: user, aoijs: aoijs, djs:djs, html:html, lua:lua})
})})})})    
})
}else{
  res.redirect("/login")
}
}

module.exports = {
  main: main_get,
  //add
  aoi_add: aoi_add,
  html_add: html_add,
  discord_add: discord_add,
  lua_add: lua_add,                               
  //site
  kurallar: kurallar,
  iletisim: iletisim,
  search: search,
  user: user,
  //codes
  aoijs_codes: aoijs_codes,
  html_codes: html_codes,
  discordjs_codes: discordjs_codes,
  lua_codes: lua_codes
};
