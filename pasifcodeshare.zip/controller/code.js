const Aoijs = require("../models/aoijs-codes");
const Html = require("../models/html-codes");
const Discordjs = require("../models/discordjs-codes");
const Lua = require("../models/lua-codes")
const User = require("../models/users")

//aoijs code
var aoijs_code = (req,res) => {
if(req.session.userId){
Aoijs.findById(req.params.id, function(error, data){
if(error){
res.send('hata !')
}else{
res.render('code/aoijs', {data: data, title: `Aoijs Code - ${data.title}`, username: req.session.username})
}
})
}else{
  res.redirect('/login')
}
}

//html code
var html_code = (req,res) => {
if(req.session.userId){
Html.findById(req.params.id, function(error, data){
if(error){
res.send('hata !')
}else{
res.render('code/html', {data: data, title:`HTML - ${data.title}`, username: req.session.username})
}
})
}else{
  res.redirect('/login')
}
}

//discordjs code
var discordjs_code = (req,res) => {
if(req.session.userId){
Discordjs.findById(req.params.id, function(error, data){
if(error){
res.send('hata !')
}else{
res.render('code/discordjs', {data: data, title:`DiscordJS - ${data.title}`, username: req.session.username})
}
})
}else{
  res.redirect('/login')
}
}

//lua code
var lua_code = (req,res) => {
if(req.session.userId){
Lua.findById(req.params.id, function(error, data){
if(error){
res.send('hata !')
}else{
res.render('code/lua', {data: data, title:`Lua - ${data.title}`, username: req.session.username})
}
})
}else{
  res.redirect('/login')
}
}

//Aoijs like
var aoijs_like = (req,res)=>{
  if(req.session.userId){
    Aoijs.findOne({title: req.query.title}, function(err,data){
 var like = parseInt(data.like);     
if(data.likeatanlar == req.session.username){ 
data.likeatanlar=-req.session.username
data.like=like-1  
  data.save()
  res.redirect(`/aoijs-code/${data._id}`)
 }else{
data.likeatanlar=req.session.username
data.like=like+1
data.save()
 res.redirect(`/aoijs-code/${data._id}`)   
}
    })
}else{
    res.redirect("/login")
}
} 

//Html like
var html_like = (req,res)=>{
  if(req.session.userId){
    Html.findOne({title: req.query.title}, function(err,data){
 var like = parseInt(data.like);     
if(data.likeatanlar == req.session.username){ 
data.likeatanlar=-req.session.username
data.like=like-1  
  data.save()
  res.redirect(`/html-code/${data._id}`)
 }else{
data.likeatanlar=req.session.username
data.like=like+1
data.save()
 res.redirect(`/html-code/${data._id}`)   
}
    })
}else{
    res.redirect("/login")
}
} 

//Discordjs like
var discordjs_like = (req,res)=>{
  if(req.session.userId){
    Discordjs.findOne({title: req.query.title}, function(err,data){
 var like = parseInt(data.like);     
if(data.likeatanlar == req.session.username){ 
data.likeatanlar=-req.session.username
data.like=like-1  
  data.save()
  res.redirect(`/discordjs-code/${data._id}`)
 }else{
data.likeatanlar=req.session.username
data.like=like+1
data.save()
 res.redirect(`/discordjs-code/${data._id}`)   
}
    })
}else{
    res.redirect("/login")
}
} 

//Lua like
var lua_like = (req,res)=>{
  if(req.session.userId){
    Lua.findOne({title: req.query.title}, function(err,data){
 var like = parseInt(data.like);     
if(data.likeatanlar == req.session.username){ 
data.likeatanlar=-req.session.username
data.like=like-1  
  data.save()
  res.redirect(`/lua-code/${data._id}`)
 }else{
data.likeatanlar=req.session.username
data.like=like+1
data.save()
 res.redirect(`/lua-code/${data._id}`)   
}
    })
}else{
    res.redirect("/login")
}
} 

module.exports = {
  aoijs_code: aoijs_code,
  html_code: html_code,
  discordjs_code: discordjs_code,
  lua_code: lua_code,
  //Like
  aoijs_like: aoijs_like,
  html_like: html_like,
  discordjs_like: discordjs_like,
  lua_like: lua_like    
}