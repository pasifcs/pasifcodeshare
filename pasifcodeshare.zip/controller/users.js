const User = require("../models/users");
const Html = require("../models/html-codes");
const Aoi = require("../models/aoijs-codes");
const Discord = require("../models/discordjs-codes");
const Lua = require("../models/lua-codes")
const config = require('../config');
const path = require("path");
const nodemailer = require("nodemailer");

var dashboard = (req, res) => {
  if (!req.session.userId) {
    res.redirect("/login");
  }else {
    User.findById(req.session.userId, function(err,user){
      let sahip = req.session.username;
    Aoi.find({sahip: sahip}, function(err,aoijs){  
    Html.find({sahip: sahip}, function(err,html){  
    Discord.find({sahip: sahip}, function(err,discordjs){  
    Lua.find({sahip: sahip}, function(err,lua){
    res.render('users/dashboard', {title: config.dashboardTitle, user: user, aoijs: aoijs, html: html, discordjs: discordjs, lua: lua})
    })
    })
    })
    })
    }) 
  }};

var login_get = (req, res) => {
  if (req.session.userId) {
    res.send("zaten giriş yaptın");
  } else {
    res.render("users/login", {title: config.loginTitle, registerSuccess: req.flash("registerSuccess"), loginError: req.flash("loginError"), loginBulunamadi: req.flash("loginBulunamadi")})
}};

var register_get = (req, res) => {
  res.render("users/register", {title: config.registerTitle, registerError: req.flash('registerError')});
};

var login_post = function(req, res) {
  const { username, password } = req.body;

  User.findOne({ username }, (error, user) => {
    if (user) {
      if(user.active == true){
      if ((user.password == password)) {
        req.session.userId = user._id;
        req.session.username = user.username
        res.redirect("/dashboard");
      } else {
        req.flash('loginError', 'Kullanıcı Adı veya Şifre Hatalı !')
        res.redirect("/login");
      }
     }else{
      res.send(`Bunun için hesabınızı doğrulamalısınız.`)
     }
    } else {
req.flash('loginBulunamadi', 'Girilen Kullanıcı Adı ve Şifreyle Eşleşen Hesap Bulunamadı !')
      res.redirect("/login");
    }
  });
};

var register_post = async function(req, res, error) {
var mail_code = Math.abs(Math.floor(Math.random() * (100000 - 900000)));
  const user = new User({
    username: req.body.username,
    password: req.body.password,
    email: req.body.email,
    image: `/img/users/${req.files.userimage.name}`,
    rank: "Üye",
    active: false,
    mail_code: mail_code
  });
  user.save()
//Mail gönderme
  let transporter = nodemailer.createTransport({
    host: "smtp.yandex.com",
    port: 465,
    secure: true,
    auth: {
      user: config.mailuser,     
      pass: config.mailpass
    },
  });
  let info = await transporter.sendMail({
    from: process.env.user,
    to: req.body.email,
    subject: "ProjeKodun",
    text: "Doğrulama Kodunuz",
    html: `<h1>${mail_code}</h2>`,
  });
  
  let image = req.files.userimage
  image.mv(path.resolve(__dirname, "../public/img/users", image.name))
  if(!error){
req.flash('registerError', 'Bir Hata Meydana Geldi !')
res.redirect("/register")
}else{
    res.redirect(`/mail-verify/${req.body.username}`)
 /* req.flash('registerSuccess', 'Başarıyla Kayıt Oldun !')
  res.redirect("/login")*/
}
};

var mail_verify = (req,res) => {
User.findOne({username: req.params.user}, function(err,user){
  if(user){
    if(user.active != true){
res.render("users/mail-verify", {title: "Hesabını Doğrula", user: user.username})
    }else{
      res.send("Zaten hesabını daha önce doğruladın !")
    }
  }else{
    res.send("Böyle bir kullanıcı bulunamadı !")
  }
})
}

var mail_verify_post = function(req,res){
User.findOne({username: req.params.user}, function(err,user){
  if(user){
    if(user.active != true){
if(user.mail_code == req.body.code){
  user.mail_code=0
  user.active=true
  user.save()
  res.send("Başarılı !")
}else{
  res.send("Hatalı kod !")
}
 }else{
   res.send("Zaten hesabını daha önce doğruladın !")   
    }
  }else{
    res.send("Böyle bir kullanıcı bulunamadı !")
  }
})
}    

var logout = (req, res) =>{
if(req.session.userId){
req.session.destroy()
res.redirect('/')
}else{
  res.send('Giriş yapmamışsın !')
}
}

//profil
var profil = (req,res) => {
  if(req.session.userId){
  User.findById(req.session.userId, function(error,data) {
if(error){
res.send("Bir Hata Meydana Geldi !")
}else{
  res.render("users/profil", {data: data, title: config.profilTitle})
}
})
}else{
    res.redirect("/login")
}
}                 

module.exports = {
  login_get: login_get,
  register_get: register_get,
  login_post: login_post,
  register_post: register_post,
  logout: logout,
  dashboard: dashboard,
  //profil
  profil: profil,
  mail_verify: mail_verify,
  mail_verify_post: mail_verify_post
};
