const User = require('../models/users')
const config= require('../config')
const Html = require("../models/html-codes");
const Aoijs = require("../models/aoijs-codes");
const Discordjs = require("../models/discordjs-codes");
const Lua = require("../models/lua-codes")

//kodlar
 var aoi = (req,res)=> {
 if(req.session.userId){
   if(req.session.userId == config.admin){
     if(req.params.onay == "true"){
 //onay true
       Aoijs.find({onay: true}, function(error,data){
 if(error){
 res.send('hata !')
 }else{
   res.render('admin/aoijs-codes', {aois: data, title: "codes"})
 }
 })
   }else if(req.params.onay == "false"){
   // onay false    
     Aoijs.find({onay: false}, function(error,data){
 if(error){
 res.send('hata !')
 }else{
   res.render('admin/aoijs-onay-codes', {aois: data, title: "codes"})
}
 }) 
   }else{
       res.send('Bulunamadı !')
  }
   }else{
    res.send('Başarısız Giriş !')
   }
}else{
 res.redirect('/login')
 }
   }

 //html
 var html = (req,res)=> {
 if(req.session.userId){
  if(req.session.userId == config.admin){
     if(req.params.onay == "true"){
 //onay true
     Html.find({onay: true}, function(error,data){
 if(error){
res.send('hata !')
 }else{
  res.render('admin/html-codes',{htmls: data, title: "codes"})
 }
})
 }else if(req.params.onay == "false"){
  // onay false    
    Html.find({onay: false}, function(error,data){
 if(error){
 res.send('hata !')
 }else{
  res.render('admin/html-onay-codes', {htmls: data, title: "codes"})
 }
 }) 
  }else{
       res.send('Bulunamadı !')
  }
   }else{
     res.send('Başarısız Giriş !')
   }
 }else{
 res.redirect('/login')
 }
    }

 // discordjs

 var discord = (req,res)=> {
 if(req.session.userId){
   if(req.session.userId == config.admin){
     if(req.params.onay == "true"){
 //onay true
      Discordjs.find({onay: true}, function(error,data){
if(error){
 res.send('hata !')
 }else{
   res.render('admin/discordjs-codes',{discords: data, title: "codes"})
 }
 })
   }else if(req.params.onay == "false"){
   // onay false    
     Discordjs.find({onay: false}, function(error,data){
 if(error){
 res.send('hata !')
 }else{
   res.render('admin/discordjs-onay-codes', {discords: data, title: "codes"})
 }
 }) 
  }else{
      res.send('Bulunamadı !')
  }
   }else{
     res.send('Başarısız Giriş !')
  }
 }else{
 res.redirect('/login')
 }}


 //lua
 var lua = (req,res)=> {
 if(req.session.userId){
   if(req.session.userId == config.admin){
     if(req.params.onay == "true"){
 //onay true
     Lua.find({onay: true}, function(error,data){
if(error){
 res.send('hata !')
 }else{
   res.render('admin/lua-codes',{luas: data, title: "codes"})
 }
 })
   }else if(req.params.onay == "false"){
   // onay false    
     Lua.find({onay: false}, function(error,data){
 if(error){
 res.send('hata !')
 }else{
   res.render('admin/lua-onay-codes', {luas: data, title: "codes"})
 }
 }) 
  }else{
      res.send('Bulunamadı !')
  }
   }else{
     res.send('Başarısız Giriş !')
  }
 }else{
 res.redirect('/login')
 }}
   
var admin_panel = (req,res)=> {
if(req.session.userId == config.admin){
res.render('admin/dashboard', {title: config.adminPanelTitle})

 }else{
 res.send('başarısız giriş !')
}
}

//onay verme
var aoijs_onay = (req,res)=>{
  if(req.session.userId){
    User.findById(req.session.userId, function(err,user){
let rank = user.rank;
if(rank == "Kurucu" || rank == "Yetkili" || rank == "Moderatör"){
Aoijs.findById(req.params.id, function(error,data){
if(error){
res.send("hata !")
}else{
  data.onay="true",
  data.durum="Kod Aktif !"
  data.save()
  res.send("Kod başarıyla onaylandı !")
}
})
}else{
   res.send("Bunun için rütben yetmiyor !")
}
    })
}else{
    res.redirect("/login")
}
}

var html_onay = (req,res)=>{
  if(req.session.userId){
  User.findById(req.session.userId, function(err,user){
let rank = user.rank;
if(rank == "Kurucu" || rank == "Yetkili" || rank == "Moderatör"){
Html.findById(req.params.id, function(error,data){
if(error){
res.send("hata !")
}else{
  data.onay="true",
  data.durum="Kod Aktif !"
  data.save()
  res.send("Kod başarıyla onaylandı !")
}
})
}else{
   res.send("Bunun için rütben yetmiyor !")
}
  })
}else{
    res.redirect("/login")
}
}

var discordjs_onay = (req,res)=>{
  if(req.session.userId){
    User.findById(req.session.userId, function(err,user){
let rank = user.rank;
      if(rank == "Kurucu" || rank == "Yetkili" || rank == "Moderatör"){
Discordjs.findById(req.params.id, function(error,data){
if(error){
res.send("hata !")
}else{
  data.onay="true",
  data.durum="Kod Aktif !"
  data.save()
  res.send("Kod başarıyla onaylandı !")
}
})
}else{
   res.send("Bunun için rütben yetmiyor !")
}
    })
}else{
    res.redirect("/login")
}
}

var lua_onay = (req,res)=>{
  if(req.session.userId){
    User.findById(req.session.userId, function(err,user){
let rank = user.rank;
if(rank == "Kurucu" || rank == "Yetkili" || rank == "Moderatör"){
Lua.findById(req.params.id, function(error,data){
if(error){
res.send("hata !")
}else{
  data.onay="true",
  data.durum="Kod Aktif !"
  data.save()
  res.send("Kod başarıyla onaylandı !")
}
})
}else{
   res.send("Bunun için rütben yetmiyor !")
}
    })
}else{
    res.redirect("/login")
}
}

module.exports = {
admin_panel: admin_panel,
//codes
aoi: aoi,
html: html,
discord: discord,
lua: lua,
//onay
aoijs_onay: aoijs_onay,
html_onay: html_onay,
discordjs_onay: discordjs_onay,
lua_onay: lua_onay
}