const Altyapi = require("../models/altyapilar");
const User = require("../models/users");

var add = (req,res) => {
  if(req.session.userId){
 User.findById(req.session.userId, function(err,user){
   if(
user.rank=="Yazılımcı" || 
user.rank=="Usta Yazılımcı" || user.rank=="Moderatör" ||
user.rank=="Yetkili" || 
user.rank=="Kurucu"
   ){
res.render("altyapilar/add",{title: "AltYapı Ekle"})
   }else{
     res.send("AltYapı eklemek için en az <b>Yazılımcı</b> rütbesine sahip olmalısın !")
   }
 })
 }else{
    res.redirect("/login")
 }
}

var add_post = function(req,res){
  if(req.session.userId){
 User.findById(req.session.userId, function(err,user){
   if(
user.rank=="Yazılımcı" || 
user.rank=="Usta Yazılımcı" || user.rank=="Moderatör" ||
user.rank=="Yetkili" || 
user.rank=="Kurucu"
   ){
    if(req.body.kategori != "Lütfen Bir Kategori Seçin"){
    if(req.body.ozel == "on"){
      var altyapi = new Altyapi({
        title: req.body.title,
        description: req.body.description,
        kategori: req.body.kategori,
        link: req.body.link,
        ozel: true
      })
    altyapi.save()
      res.send("Başarılı !")
    }else{      
      var altyapi = new Altyapi({
        title: req.body.title,
        description: req.body.description,
        kategori: req.body.kategori,
        link: req.body.link,
        ozel: false,
        sahip: req.session.username
      })
    altyapi.save()
      res.send("Başarılı !")
    }
}else{
      res.send(req.body.kategori+" Bir kategori seçmelisin !")
}
   }else{
     res.send("AltYapı eklemek için en az <b>Yazılımcı</b> rütbesine sahip olmalısın !")
   }
 })
 }else{
    res.redirect("/login")
 }
}

var altyapilar = (req,res)=>{
  if(req.session.userId){
  if(
    req.query.kategori == "aoijs" ||
    req.query.kategori == "html" ||
    req.query.kategori == "discordjs" ||
    req.query.kategori == "lua"   
    ){
Altyapi.find({kategori: "aoijs"}, function(err,aoijs){
Altyapi.find({kategori: "html"}, function(err,html){
Altyapi.find({kategori: "discordjs"}, function(err,djs){
Altyapi.find({kategori: "lua"}, function(err,lua){
User.findById(req.session.userId, function(err,user){  
res.render("altyapilar/main", {
  aoijs: aoijs,
  html: html,
  djs: djs,
  lua: lua,
  kategori: req.query.kategori,
  title: "AltYapılar",
  user: user
})
})
})
})
})
})
}else{
    res.send("Böyle bir kategori yok.")
  }
  }else{
    res.redirect("/login")
}
}

var altyapi = (req,res) => {
  if(req.session.userId){
 User.findById(req.session.userId, function(err,user){
   
Altyapi.findOne({title: req.query.title}, function(err,data){
  if(data){
   if(data.ozel==true){
     if(
user.rank=="Yazılımcı" || 
user.rank=="Usta Yazılımcı" || user.rank=="Moderatör" ||
user.rank=="Yetkili" || 
user.rank=="Kurucu" ||
user.rank=="VIP"       
  ){
    res.render("altyapilar/altyapi", {title: data.title, data: data})  
    }else{
     res.send("Bu altyapıyı görüntülemek için en az <b>VIP</b> rütbesine sahip olman gerekli !")
    }
     }else{     
    res.render("altyapilar/altyapi", {title: data.title, data: data})  
     }
  }else{
    res.send("Böyle bir altyapı bulunamadı !")
  }
})
 })
 }else{
    res.redirect("/login")
     }
}
                             
module.exports = {
  add: add,
  add_post: add_post,
  altyapilar: altyapilar,
  altyapi: altyapi
}