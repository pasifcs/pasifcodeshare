const express = require("express");
const router = express.Router();
const Users = require("../models/users");
const Aoijs = require("../models/aoijs-codes");
const Html = require("../models/html-codes");
const Discordjs = require("../models/discordjs-codes");
const Lua = require("../models/lua-codes")
const config = require("../config")  

var kurucu_panel = (req,res)=>{
  if(req.session.userId){
 Users.findById(req.session.userId, function(err,user){
  if(user.rank == "Kurucu"){
Users.find({}, function(err,users){
res.render("ranks/kurucu-panel", {title: "Kurucu Panel", users: users})
}).sort({createdAt: -1})
}else{
    res.send("Bunun İçin Rütben Yetersiz !")
}
})
}else{
    res.redirect("/login")
}
}

var yetkili_panel = (req,res)=>{
  if(req.session.userId){
 Users.findById(req.session.userId, function(err,user){
  if(user.rank == "Yetkili" || user.rank == "Kurucu"){
Users.find({}, function(err,users){
res.render("ranks/yetkili-panel", {title: "Yetkili Panel", users: users})
}).sort({createdAt: -1})
}else{
    res.send("Bunun İçin Rütben Yetersiz !")
}
})
}else{
    res.redirect("/login")
}
}  

var moderator_panel = (req,res)=>{
  if(req.session.userId){
 Users.findById(req.session.userId, function(err,user){
  if(user.rank == "Moderatör" || user.rank == "Kurucu" || user.rank == "Yetkili"){
Aoijs.find({}, function(err,aoijs){
Html.find({}, function(err,html){
Discordjs.find({}, function(err,djs){
Lua.find({}, function(err,lua){
  
res.render("ranks/moderator-panel", {title: "Moderatör Panel", 
aoijs: aoijs,
djs: djs, 
html: html,
lua: lua,
codeDeleteModError: req.flash("codeDeleteModError"),
codeDeleteModSuccess: req.flash("codeDeleteModSuccess"),
codeDeleteNoneError: req.flash("codeDeleteNoneError")    
})
}).sort({createdAt: -1})
}).sort({createdAt: -1})
}).sort({createdAt: -1})
}).sort({createdAt: -1})   

}else{
    res.send("Bunun İçin Rütben Yetersiz !")
}
})
}else{
    res.redirect("/login")
}
}

var ranks = (req,res) => {
if(req.session.userId){
Users.findById(req.session.userId, function(err,user1){
   if(user1.rank == "Yetkili" || user1.rank == "Kurucu"){
let name = req.params.username;
  Users.findOne({username: name}, function(err,user){
let username = user.username;    
 Aoijs.find({sahip: username}, function(err,aoijs){
  Discordjs.find({sahip: username}, function(err,djs){
    Html.find({sahip: username}, function(err,html){
      Lua.find({sahip: username}, function(err,lua){                
res.render("ranks/ranks", {title: config.ranksTitle, user: user, aoijs: aoijs, djs:djs, html:html, lua:lua, user1: user1})
})})})})
})
}else{
    res.send("Bunun için rütben yetersiz.")
}
})  
}else{
  res.redirect("/login")
}
}

var rank_update = function(req,res){
if(req.session.userId){
  Users.findById(req.session.userId, function(err,user1){
if(user1.rank == "Kurucu" || user1.rank == "Yetkili"){
  Users.findById(req.params.id, function(err,user){
  if(user1.rank == "Kurucu" && req.body.ranks == "Yetkili"){
    user.rank = req.body.ranks
    user.save()
    res.send("İşlem Başarılı !")
  }else if(user1.rank == "Kurucu" && req.body.ranks == "Moderatör"){
    user.rank = req.body.ranks
    user.save()
    res.send("İşlem Başarılı !")
  }else{
    user.rank = req.body.ranks 
    user.save()
    res.send("İşlem Başarılı !")
  }
})
}else{
  res.send("Bunun için rütben yetersiz.")
}
})
}else{
  res.redirect("/login")
}
}

module.exports = {
  kurucu_panel: kurucu_panel,
  yetkili_panel: yetkili_panel,
  moderator_panel: moderator_panel,
  ranks: ranks,
  rank_update: rank_update
}