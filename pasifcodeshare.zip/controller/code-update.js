const Aoijs = require("../models/aoijs-codes");
const Html = require("../models/html-codes");
const Discordjs = require("../models/discordjs-codes");
const Lua = require("../models/lua-codes")
const config = require('../config')
//discordjs
const discordjs = require("discord.js")  
const client = new discordjs.Client()    
require('../bot/util/Loader.js')(client);
const botconfig = require("../bot/config")
client.login(config.token)

//aoijs
var aoijs_update_get = (req,res) =>{
Aoijs.findById(req.params.id, function(error, data) {
  if(data){
if(req.session.userId){
if(req.session.username == data.sahip){
res.render('code-update/aoijs-update', {data: data, title: config.AoijsCodeUpdateTitle})
}else{
  res.send('Bu kodun sahibi sen degilsin !')
}
}else{
  res.redirect('/login')
}
  }else{
    res.send("Böyle bir kod bulunamadı !")
  }
})
}

var aoijs_update_post = function(req,res) { 
  if(req.session.userId){

    Aoijs.findById(req.params.id, (error,data) => {   
      if(data){
      if(req.session.username == data.sahip){

  data.title=req.body.title
  data.description=req.body.description
  data.code=req.body.code
  data.onay=false
  data.durum="Düzenlendi. Onaylanmayı Bekliyor !"      
     data.save()   
    if(error){
      req.flash('aoijsUpdateError', 'Bir Hata Meydana Geldi !')
      res.redirect("/dashboard/aoijs")
}else{   
  client.channels.cache.get(botconfig.logKanal).send(
    new discordjs.MessageEmbed()
    .setColor("BLUE")
    .setTitle("Bir AoiJS Kodu Güncellendi !")
    .setDescription(`**Kodun Linki** \n [${data.title}](https://www.projekodun.tk/aoijs-code/${req.params.id})`)
  );    
    req.flash('aoijsUpdateSuccess', 'Kod Başarıyla Güncellendi !') 
res.redirect("/dashboard/aoijs") 
}      
    }else{
        res.send('Bu kodun sahibi sen degilsin !')
    }
      }else{
        res.send("Böyle bir kod bulunamadı !")
      }    
      }) }else{
    res.redirect('/login')
  }
}
//html
var html_update_get = (req,res) =>{
Html.findById(req.params.id, function(error, data) {
  if(data){
if(req.session.userId){
if(req.session.username == data.sahip){
res.render('code-update/html-update', {data: data, title: config.HtmlCodeUpdateTitle})
}else{
  res.send('Bu kodun sahibi sen degilsin !')
}
}else{
  res.redirect('/login')
}
  }else{
    res.send("Böyle bir kod bulunamadı !")
  }
})
}

var html_update_post = function(req,res) { 
  if(req.session.userId){

    Html.findById(req.params.id, (error,data) => {   
      if(data){
      if(req.session.username == data.sahip){

  data.title=req.body.title
  data.description=req.body.description
  data.code=req.body.code
  data.onay=false
  data.durum="Düzenlendi. Onaylanmayı Bekliyor !"  
     data.save()   
    if(error){
req.flash('htmlUpdateError', 'Bir Hata Meydana Geldi !')
res.redirect('/dashboard/html')
} else{ 
  client.channels.cache.get(botconfig.logKanal).send(
    new discordjs.MessageEmbed()
    .setColor("BLUE")
    .setTitle("Bir HTML Kodu Güncellendi !")
    .setDescription(`**Kodun Linki** \n [${data.title}](https://www.projekodun.tk/html-code/${req.params.id})`)
  );    
      req.flash('htmlUpdateSuccess', 'Kod Başarıyla Güncellendi !')
      res.redirect('/dashboard/html')
}      
    }else{
        res.send('Bu kodun sahibi sen degilsin !')
    }
      }else{
        res.send("Böyle bir kod bulunamadı !")
      }    
      }) }else{
    res.redirect('/login')
  }
}
//discordjs 
var discordjs_update_get = (req,res) =>{
Discordjs.findById(req.params.id, function(error, data) {
  if(data){
if(req.session.userId){
if(req.session.username == data.sahip){
res.render('code-update/discordjs-update', {data: data, title: config.DiscordjsCodeUpdateTitle})
}else{
  res.send('Bu kodun sahibi sen degilsin !')
}
}else{
  res.redirect('/login')
}
  }else{
    res.send("Böyle bir kod bulunamadı !")
  }
})
}

var discordjs_update_post = function(req,res) { 
  if(req.session.userId){

    Discordjs.findById(req.params.id, (error,data) => {   
      if(data){
      if(req.session.username == data.sahip){

  data.title=req.body.title
  data.description=req.body.description
  data.code=req.body.code
  data.onay=false
  data.durum="Düzenlendi. Onaylanmayı Bekliyor !"        
     data.save()   
    if(error){
req.flash('discordjsUpdateError', 'Bir Hata Meydana Geldi !')
res.redirect("/dashboard/discordjs")
}else{ 
  client.channels.cache.get(botconfig.logKanal).send(
    new discordjs.MessageEmbed()
    .setColor("BLUE")
    .setTitle("Bir DiscordJS Kodu Güncellendi !")
    .setDescription(`**Kodun Linki** \n [${data.title}](https://www.projekodun.tk/discordjs-code/${req.params.id})`)
  );    
      req.flash('discordjsUpdateSuccess', 'Kod Başarıyla Güncellendi !')
      res.redirect("/dashboard/discordjs")
}
    }else{
        res.send('Bu kodun sahibi sen degilsin !')
    }
      }else{
res.send("Böyle bir kod bulunamadı !")
}    
      }) }else{
    res.redirect('/login')
  }
}

//lua 
var lua_update_get = (req,res) =>{
Lua.findById(req.params.id, function(error, data) {
  if(data){
if(req.session.userId){
if(req.session.username == data.sahip){
res.render('code-update/lua-update', {data: data, title: config.LuaCodeUpdateTitle})
}else{
  res.send('Bu kodun sahibi sen degilsin !')
}
}else{
  res.redirect('/login')
}
  }else{
    res.send("Böyle bir kod bulunamadı !")
  }
})
}

var lua_update_post = function(req,res) { 
  if(req.session.userId){

    Lua.findById(req.params.id, (error,data) => {   
      if(data){
      if(req.session.username == data.sahip){

  data.title=req.body.title
  data.description=req.body.description
  data.code=req.body.code
  data.onay=false
  data.durum="Düzenlendi. Onaylanmayı Bekliyor !"        
     data.save()   
    if(error){
req.flash('luaUpdateError', 'Bir Hata Meydana Geldi !')
res.redirect("/dashboard/lua")
}else{ 
  client.channels.cache.get(botconfig.logKanal).send(
    new discordjs.MessageEmbed()
    .setColor("BLUE")
    .setTitle("Bir Lua Kodu Güncellendi !")
    .setDescription(`**Kodun Linki** \n [${data.title}](https://www.projekodun.tk/lua-code/${req.params.id})`)
  );    
      req.flash('luaUpdateSuccess', 'Kod Başarıyla Güncellendi !')
      res.redirect("/dashboard/lua")
}
    }else{
        res.send('Bu kodun sahibi sen degilsin !')
    }
      }else{
        res.send("Böyle bir kod bulunamadı !")
      }   
      }) }else{
    res.redirect('/login')
  }
}


module.exports = {
  aoijs_update_get: aoijs_update_get,
  aoijs_update_post: aoijs_update_post,
  html_update_get: html_update_get,
  html_update_post: html_update_post,
  discordjs_update_get: discordjs_update_get,
  discordjs_update_post: discordjs_update_post,
  lua_update_get: lua_update_get,
  lua_update_post: lua_update_post
}