const Aoijs = require('../models/aoijs-codes');
const Discordjs = require('../models/discordjs-codes');
const Html = require('../models/html-codes');
const config = require("../config")
const Lua = require("../models/lua-codes")

var discord = (req,res) => {
  if(req.session.username){
Discordjs.find({sahip: req.session.username}).sort({createdAt: -1})
    .then(result => {
    res.render("dashboard/discordjs-codes",{discords: result, title: config.DiscordjsCodesDashboardTitle, discordjsAddSuccess: req.flash("discordjsAddSuccess"), discordjsDeleteSuccess: req.flash("discordjsDeleteSuccess"), discordjsDeleteError: req.flash('discordjsDeleteError'), 
      discordjsUpdateSuccess: req.flash("discordjsUpdateSuccess"),
      discordjsUpdateError: req.flash("discordjsUpdateError")})
    })
    }
  else{
    res.send('hata ! giriş yapmalısın')
  }
}

var html = (req,res) => {
  if(req.session.username){
Html.find({sahip: req.session.username}).sort({createdAt: -1})
    .then(result => {
    res.render("dashboard/html-codes",{htmls: result, title: config.HtmlCodesDashboardTitle, htmlAddSuccess: req.flash("htmlAddSuccess"), htmlDeleteSuccess: req.flash("htmlDeleteSuccess"), htmlDeleteError: req.flash("htmlDeleteError"), 
      htmlUpdateSuccess: req.flash("htmlUpdateSuccess"),
      htmlUpdateError: req.flash("htmlUpdateError")})
    })
    }
  else{
    res.send('hata ! giriş yapmalısın')
  }
}

var aoi = (req,res) => {
  if(req.session.username){
Aoijs.find({sahip: req.session.username}).sort({createdAt: -1})
    .then(result => {
    res.render("dashboard/aoijs-codes",{
      aois: result, title: config.AoijsCodesDashboardTitle, 
      aoijsAddSuccess: req.flash("aoijsAddSuccess"), 
      aoijsDeleteSuccess: req.flash("aoijsDeleteSuccess"), 
      aoijsDeleteError: req.flash("aoijsDeleteError"), 
      aoijsUpdateSuccess: req.flash("aoijsUpdateSuccess"),
      aoijsUpdateError: req.flash("aoijsUpdateError")})
    })
    }
  else{
    res.send('hata ! giriş yapmalısın')
  }
}


var lua = (req,res) => {
  if(req.session.username){
Lua.find({sahip: req.session.username}).sort({createdAt: -1})
    .then(result => {
    res.render("dashboard/lua-codes",{
      luas: result, title: config.LuaCodesDashboardTitle, 
      luaAddSuccess: req.flash("luaAddSuccess"), 
      luaDeleteSuccess: req.flash("luaDeleteSuccess"), 
      luaDeleteError: req.flash("luaDeleteError"), 
      luaUpdateSuccess: req.flash("luaUpdateSuccess"),
      luaUpdateError: req.flash("luaUpdateError")})
    })
    }
  else{
    res.send('hata ! giriş yapmalısın')
  }
}

module.exports = {
 aoi:aoi,
  discord: discord,
  html: html,
  lua: lua
}