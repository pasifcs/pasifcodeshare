const Aoijs = require("../models/aoijs-codes");
const Html = require("../models/html-codes");
const Discordjs = require("../models/discordjs-codes");
const User = require("../models/users")
const Lua = require("../models/lua-codes")
//discordjs
const discordjs = require("discord.js")  
const client = new discordjs.Client()    
require('../bot/util/Loader.js')(client);
const config = require("../config")
client.login(config.token)

var aoijs_delete = (req,res) => {
if(req.session.userId){
Aoijs.findById(req.params.id, function(error, data){
  User.findById(req.session.userId, function(err,user){
    if(data && user){
  if(req.session.username == data.sahip){
       Aoijs.findByIdAndDelete(req.params.id, function(error,data){
 if(error){
req.flash("aoijsDeleteError", "Bir Hata Meydana Geldi !")
   res.redirect("/dashboard/aoijs")
}else{
client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir AoiJS Kodu Silindi !")
  .setDescription(`Kod, sahibi tarafından silindi ! \n Kodun sahibi: ${req.session.username}`)
);
req.flash('aoijsDeleteSuccess', 'Kod Başarıyla Silindi !')
   res.redirect("/dashboard/aoijs")
 } 
})
  }else if(user.rank == "Moderatör" || user.rank == "Kurucu" || user.rank == "Yetkili"){
  Aoijs.findByIdAndDelete(req.params.id, function(err,data){
    if(err){
      req.flash("codeDeleteModError", "Bir Hata Meydana Geldi !")
      res.redirect("/dashboard/moderator-panel")
    }else{           client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir AoiJS Kodu Silindi !")
  .setDescription(`Kod, bir yetkili tarafından silindi ! \n Kodu silen yetkili: ${req.session.username}`)
);
      req.flash("codeDeleteModSuccess", "Kod Başarıyla Silindi !")
      res.redirect("/dashboard/moderator-panel")
    }
})
  }else{
    res.send("bu kodun sahibi sen değilsin !")
  }
    }else{
      req.flash("codeDeleteNoneError", "Böyle bir kod bulunamadı !")
      res.redirecy("/dashboard/moderator-panel")
    }
  })
})
}else{
  res.redirect("/login")
}
}

var html_delete = (req,res) => {
if(req.session.userId){
Html.findById(req.params.id, function(error, data){
  User.findById(req.session.userId, function(err,user){
    if(data && user){
  if(req.session.username == data.sahip){
     Html.findByIdAndDelete(req.params.id, function(error,data){
 if(error){
req.flash("htmlDeleteError", 'Bir Hata Meydana Geldi !')
res.redirect("/dashboard/html")
}else{
 client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir HTML Kodu Silindi !")
  .setDescription(`Kod, sahibi tarafından silindi ! \n Kodun sahibi: ${req.session.username}`)
);
  
req.flash('htmlDeleteSuccess', 'Kod Başarıyla Silindi !')
   res.redirect("/dashboard/html")
 } 
})
  }else if(user.rank == "Moderatör" || user.rank == "Kurucu" || user.rank == "Yetkili"){
  Html.findByIdAndDelete(req.params.id, function(err,data){
    if(err){
      req.flash("codeDeleteModError", "Bir Hata Meydana Geldi !")
      res.redirect("/dashboard/moderator-panel")
    }else{     client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir HTML Kodu Silindi !")
  .setDescription(`Kod, bir yetkili tarafından silindi ! \n Kodu silen yetkili: ${req.session.username}`)
);
      req.flash("codeDeleteModSuccess", "Kod Başarıyla Silindi !")
      res.redirect("/dashboard/moderator-panel")
    }
}) 
  }else{
    res.send("bu kodun sahibi sen değilsin !")
  }
    }else{
      req.flash("codeDeleteNoneError", "Böyle bir kod bulunamadı !")
      res.redirect("/dashboard/moderator-panel")
    }
})
})
}else{
  res.redirect("/login")
}
}

var discordjs_delete = (req,res) => {
if(req.session.userId){
Discordjs.findOne({_id: req.params.id}, function(error, data){ 
  User.findById(req.session.userId, function(err,user){
    if(data && user){
  if(req.session.username == data.sahip){
     Discordjs.findByIdAndDelete(req.params.id, function(error,data){
 if(error){
   req.flash('discordjsDeleteError', 'Bir Hata Meydana Geldi !')
res.redirect('/dashboard/discordjs')
}else{
   client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir DiscordJS Kodu Silindi !")
  .setDescription(`Kod, sahibi tarafından silindi ! \n Kodun sahibi: ${req.session.username}`)
);

req.flash('discordjsDeleteSuccess', 'Kod Başarıyla Silindi !')
   res.redirect('/dashboard/discordjs')
 } 
})
    }else if(user.rank == "Moderatör" || user.rank == "Kurucu" || user.rank == "Yetkili"){
    
  Discordjs.findOneAndDelete({_id: req.params.id}, function(err,data){
    if(err){
      req.flash("codeDeleteModError", "Bir Hata Meydana Geldi !")
      res.redirect("/dashboard/moderator-panel")
    }else{     
client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir DiscordJS Kodu Silindi !")
  .setDescription(`Kod, bir yetkili tarafından silindi ! \n Kodu silen yetkili: ${req.session.username}`)
);
      req.flash("codeDeleteModSuccess", "Kod Başarıyla Silindi !")
      res.redirect("/dashboard/moderator-panel")
   }
})
  }else{
    res.send("bu kodun sahibi sen değilsin !")
  }
}else{
      req.flash("codeDeleteNoneError", "Böyle bir kod bulunamadı !")
  res.redirect("/dashboard/moderator-panel")
    }
})
    })
}else{
  res.redirect("/login")
}
}

var lua_delete = (req,res) => {
if(req.session.userId){
Lua.findById(req.params.id, function(error, data){
  User.findById(req.session.userId, function(err,user){
    if(data && user){
  if(req.session.username == data.sahip){
     Lua.findByIdAndDelete(req.params.id, function(error,data){
 if(error){
   req.flash('luaDeleteError', 'Bir Hata Meydana Geldi !')
res.redirect('/dashboard/lua')
}else{
client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir Lua Kodu Silindi !")
  .setDescription(`Kod, sahibi tarafından silindi ! \n Kodun sahibi: ${req.session.username}`)
);

req.flash('luaDeleteSuccess', 'Kod Başarıyla Silindi !')
   res.redirect('/dashboard/lua')
 } 
})
    }else if(user.rank == "Moderatör" || user.rank == "Kurucu" || user.rank == "Yetkili"){
  Lua.findByIdAndDelete(req.params.id, function(err,data){
    if(err){
      req.flash("codeDeleteModError", "Bir Hata Meydana Geldi !")
      res.redirect("/dashboard/moderator-panel")
    }else{   
client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir Lua Kodu Silindi !")
  .setDescription(`Kod, bir yetkili tarafından silindi ! \n Kodu silen yetkili: ${req.session.username}`)
);  
      req.flash("codeDeleteModSuccess", "Kod Başarıyla Silindi !")
      res.redirect("/dashboard/moderator-panel")
    }
})
  }else{
    res.send("bu kodun sahibi sen değilsin !")
  }
    }else{      
      req.flash("codeDeleteNoneError", "Böyle bir kod bulunamadı !")
      res.redirect("/dashboard/moderator-panel")
    }
})
})
}else{
  res.redirect("/login")
}
}

//Askıyla Almak
var askiya_aoijs = (req,res)=>{
  if(req.session.userId){
  User.findById(req.session.userId, function(err,user){
    if(user){
    if(user.rank == "Moderatör" || user.rank == "Yetkili" || user.rank == "Kurucu"){ 
  Aoijs.findOne({title: req.params.title}, function(err,data){
if(data){
data.onay=false
data.durum="Kod askıya alındı !"
data.save()
   client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir AoiJS Kodu Askıya Alındı !")
  .setDescription(`Kodun Adı: **${data.title}**`)
);  
    res.send("Başarılı")
}else{
  res.send(req.query.title+" adında bir kod bulunamadı !")
}
})
    }else{
      res.send("Yetersiz yetki !")
    }
  }else{
      res.redirect("/logout")
    }
  })
  }else{
    res.redirect("/login")
  }  
  }

var askiya_html = (req,res)=>{
  if(req.session.userId){
  User.findById(req.session.userId, function(err,user){
    if(user){
    if(user.rank == "Moderatör" || user.rank == "Yetkili" || user.rank == "Kurucu"){ 
  Html.findOne({title: req.params.title}, function(err,data){
if(data){
data.onay=false
data.durum="Kod askıya alındı !"
data.save()
   client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir HTML Kodu Askıya Alındı !")
  .setDescription(`Kodun Adı: **${data.title}**`)
);  
    res.send("Başarılı")
}else{
  res.send(req.query.title+" adında bir kod bulunamadı !")
}
})
    }else{
      res.send("Yetersiz yetki !")
    }
  }else{
      res.redirect("/logout")
    }
  })
  }else{
    res.redirect("/login")
  }  
  }

var askiya_discordjs = (req,res)=>{
  if(req.session.userId){
  User.findById(req.session.userId, function(err,user){
    if(user){
    if(user.rank == "Moderatör" || user.rank == "Yetkili" || user.rank == "Kurucu"){ 
  Discordjs.findOne({title: req.params.title}, function(err,data){
if(data){
data.onay=false
data.durum="Kod askıya alındı !"
data.save()
   client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir DiscordJS Kodu Askıya Alındı !")
  .setDescription(`Kodun Adı: **${data.title}**`)
);  
    res.send("Başarılı")
}else{
  res.send(req.query.title+" adında bir kod bulunamadı !")
}
})
    }else{
      res.send("Yetersiz yetki !")
    }
  }else{
      res.redirect("/logout")
    }
  })
  }else{
    res.redirect("/login")
  }  
  }

var askiya_lua = (req,res)=>{
  if(req.session.userId){
  User.findById(req.session.userId, function(err,user){
    if(user){
    if(user.rank == "Moderatör" || user.rank == "Yetkili" || user.rank == "Kurucu"){ 
  Lua.findOne({title: req.params.title}, function(err,data){
if(data){
data.onay=false
data.durum="Kod askıya alındı !"
data.save()
   client.channels.cache.get(botconfig.logKanal).send(
  new discordjs.MessageEmbed()
  .setColor("RED")
  .setTitle("Bir Lua Kodu Askıya Alındı !")
  .setDescription(`Kodun Adı: **${data.title}**`)
);  
    res.send("Başarılı")
}else{
  res.send(req.query.title+" adında bir kod bulunamadı !")
}
})
    }else{
      res.send("Yetersiz yetki !")
    }
  }else{
      res.redirect("/logout")
    }
  })
  }else{
    res.redirect("/login")
  }  
  }

module.exports = {
  aoijs_delete: aoijs_delete,
  html_delete: html_delete,
  discordjs_delete: discordjs_delete,
  lua_delete: lua_delete,
  //Askıya almak
  askiya_aoijs: askiya_aoijs,
  askiya_html: askiya_html,
  askiya_discordjs: askiya_discordjs,
  askiya_lua: askiya_lua
}