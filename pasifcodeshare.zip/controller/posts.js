const Aoijs_codes = require("../models/aoijs-codes");
const Html = require("../models/html-codes");
const Discord = require("../models/discordjs-codes");
const Lua = require("../models/lua-codes");
const config = require('../config');
const User = require("../models/users");
const fs = require("fs");
const path = require("path");
//discordjs
const discordjs = require("discord.js")  
const client = new discordjs.Client()    
require('../bot/util/Loader.js')(client);
const botconfig = require("../bot/config")
client.login(config.token)

var aoi_add = function(req, res, error) {
  if(config.kod_paylas == true){
  const aoijs_codes = new Aoijs_codes({
    title: req.body.title,
    description: req.body.description,
    code: req.body.code,
    sahip: req.session.username,
    onay: false,
    durum: "Onaylanması Bekleniyor.",
    like: 0
  })
  aoijs_codes.save()
   if(!error){
req.flash('aoijsAddError', 'Bir Hata Meydana Geldi !')
  res.redirect('/aoijs-add')  
}else{
client.channels.cache.get(botconfig.logKanal).send(
   new discordjs.MessageEmbed()   
   .setColor("BLUE")    .setThumbnail("https://cdn.dost55.repl.co/Yeni_Proje_2-modified.png")  
   .setTitle("Bir AoiJS Kodu Eklendi !")
   .addField("Kod Adı", req.body.title)
  .addField("Kodu Paylaşan", req.session.username)
   .setFooter("Kodun Onaylanması Bekleniyor...", "https://cdn.dost55.repl.co/computer-icons-symbol-clock-clock-free-button-png-044d527f6af9ffc14d83e104ccf40f10.png") 
);     
      req.flash('aoijsAddSuccess', 'Kod Başarıyla Eklendi. Kodunuz Onaylanınca Aktif Olacaktır !')
res.redirect("/dashboard/aoijs")    
  }
  }else {
    res.send('Geçici bir süreliğine kod paylaşma aktif değil !')
  }
};


var html_add = function(req, res, error) {
  if(config.kod_paylas == true){
  const html = new Html({
    title: req.body.title,
    description: req.body.description,
    code: req.body.code,
    sahip: req.session.username,
    onay: false,
    durum: "Onaylanması Bekleniyor.",
    like: 0
  });
  html
    .save()
     if(!error){
req.flash('htmlAddError', 'Bir Hata Meydana Geldi !')
  res.redirect('/html-add')  
}else{       client.channels.cache.get(botconfig.logKanal).send(
   new discordjs.MessageEmbed()   
   .setColor("BLUE") 
   .setThumbnail("https://cdn.dost55.repl.co/Yeni_Proje_2-modified.png")  
   .setTitle("Bir HTML Kodu Eklendi !")
   .addField("Kod Adı", req.body.title)
   .addField("Kodu Paylaşan", req.session.username)
   .setFooter("Kodun Onaylanması Bekleniyor...", "https://cdn.dost55.repl.co/computer-icons-symbol-clock-clock-free-button-png-044d527f6af9ffc14d83e104ccf40f10.png") 
);
      req.flash('htmlAddSuccess', 'Kod Başarıyla Eklendi. Kodunuz Onaylanınca Aktif Olacaktır !')
res.redirect("/dashboard/html")
     }
}else {
  res.send('Geçici bir süreliğine kod paylaşma aktif değil !')   
}
};

var discord_add = function(req, res, error) {
  if(config.kod_paylas == true){
  const discord = new Discord({
    title: req.body.title,
    description: req.body.description,
    code: req.body.code,
    sahip: req.session.username,
    onay: false,
    durum: "Onaylanması Bekleniyor.",
    like: 0
  });
  discord
    .save()
     if(!error){
req.flash('discordjsAddError', 'Bir Hata Meydana Geldi !')
  res.redirect('/discordjs-add')  
}else{
 client.channels.cache.get(botconfig.logKanal).send(
   new discordjs.MessageEmbed()   
   .setColor("BLUE")  .setThumbnail("https://cdn.dost55.repl.co/Yeni_Proje_2-modified.png")  
   .setTitle("Bir DiscordJS Kodu Eklendi !")
   .addField("Kod Adı", req.body.title)
   .addField("Kodu Paylaşan", req.session.username)
   .setFooter("Kodun Onaylanması Bekleniyor...", "https://cdn.dost55.repl.co/computer-icons-symbol-clock-clock-free-button-png-044d527f6af9ffc14d83e104ccf40f10.png") 
);      
      req.flash('discordjsAddSuccess', 'Kod Başarıyla Eklendi. Kodunuz Onaylanınca Aktif Olacaktır !')
res.redirect("/dashboard/discordjs")
   }
  }else {
     res.send('Geçici bir süreliğine kod paylaşma aktif değil !')
  }
};

var lua_add = function(req, res, error) {
  if(config.kod_paylas == true){
  const lua = new Lua({
    title: req.body.title,
    description: req.body.description,
    code: req.body.code,
    sahip: req.session.username,
    onay: false,
    durum: "Onaylanması Bekleniyor.",
    like: 0
  });
 lua.save()
     if(!error){
req.flash('luaAddError', 'Bir Hata Meydana Geldi !')
  res.redirect('/lua-add')  
}else{
       client.channels.cache.get(botconfig.logKanal).send(
   new discordjs.MessageEmbed()   
   .setColor("BLUE")    .setThumbnail("https://cdn.dost55.repl.co/Yeni_Proje_2-modified.png")  
   .setTitle("Bir Lua Kodu Eklendi !")
   .addField("Kod Adı", req.body.title)
   .addField("Kodu Paylaşan", req.session.username)
   .setFooter("Kodun Onaylanması Bekleniyor...", "https://cdn.dost55.repl.co/computer-icons-symbol-clock-clock-free-button-png-044d527f6af9ffc14d83e104ccf40f10.png") 
);
      req.flash('luaAddSuccess', 'Kod Başarıyla Eklendi. Kodunuz Onaylanınca Aktif Olacaktır !')
res.redirect("/dashboard/lua")
   }
  }else {
     res.send('Geçici bir süreliğine kod paylaşma aktif değil !')
  }
};

//şifre güncelleme
var password_update = function(req,res){
if(req.session.userId){
 User.findById(req.session.userId, function(error,data){
if(data.password == req.body.eskiparola){
  data.password=req.body.yeniparola
  data.save()
  if(error){
    res.send("Bir Hata Oluştu !")
  }else{
    req.session.destroy(()=>{
    res.send("Parolan Güncellendi! <a href='/login'>Giriş Yapmak ?</a>")
   })
     }
}else{
  res.send("Hata !")
}
})
}else{
res.redirect("/login")
}
}

//avatar update
var avatar_update = function(req,res){
if(req.session.userId){
   User.findById(req.session.userId, function(error,user){
fs.unlink(`./public${user.image}`, function(err){
  if(err){
res.send("Bir Hata Oluştu !")
}else{ user.image=`/img/users/${req.files.userimage.name}`
user.save()     
let image = req.files.userimage;
image.mv(path.resolve(__dirname, "../public/img/users", image.name))
     
if(error){
res.send("Bir Hata Oluştu !")
}else{
  res.redirect("/dashboard/profil")
}    
}
})        
})
}else{
  res.redirect("/login")
}
}

module.exports = {
  aoi_add: aoi_add,
  html_add: html_add,
  discord_add: discord_add,
  lua_add: lua_add,
  //şifre güncelleme
  password_update: password_update,
  //avatar güncelleme
  avatar_update: avatar_update   
};
