window.cookieconsent.initialise({
        "palette": {
            "popup": {
                // Uyarının arkaplan rengini belirtiyoruz.
                "background": "#222"
            },
            // Uyarı butonunun rengini belirtiyoruz.
            "button": {
                "background": "#E83C4D"
            }
        },
        "theme": "edgeless",
"position": "bottom-left",
        // Bu alanda; uyarı mesajını, Buton adını, Url adını ve hedef adresi belirtiyoruz.
        "content": {
            "message": "Web Sitemizdeki Kodları , Projeleri ücretsiz Olarak Kullanabilmek için Kurallar ' ı Kabul etmelisiniz",
            "dismiss": "Kabul Ediyorum",
            "link": "Kurallar",
            "href": "/kurallar"
        }
    });

        