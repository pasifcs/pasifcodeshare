# Metini Değiştirmek
Bu Metini Değiştirmek , Silmek , adını değiştirmek , yeniden yazmak YASAKTIR Eğerki bunlardan birini yapıcaksanız projeyi kullanmayınız.

# Bu Projeyi Kimler Kullanabilir 
Pasif Studio (https://discord.gg/AJ2ntKtBWb) Discord Sunucusunda Abone Rolüne Sahip olanlar Bu Projeye erişebilir.

# Kullanım Kuralları
1 ) Bu Projeyi Kendiniz yapmış gibi tanıtamazssınız.
- Bu altyapıyı para ile SATAMAZSSINIZ KULLANIM-KURALLARI 'na UYULDUĞU SÜREÇ İÇERİSİNDE TAMAMEN ÜCRETSİZDİR !!
- Projedeki kodları Değiştirebilir. Web Siteyi değiştirdiğiniz kodlar ile birlikte yayınlayabilirsiniz.
- Projedeki Bazı Kodları Değiştirip KENDİNİZ yapmış gibi yayınlayamazssınız. Bu Projeyi Remixlediğiniz Gözükür.
- Bu Proje siyaset ile ilgili birşey için kullanılamaz
- Bu Proje Dini ile ilgili birşey için kullanılamaz
- Bu Proje Irkçılık ile ilgili birşey için kullanılamaz
- Bu Projede Küfür KULLANILAMAZ
- Web sitenin alt kısmına kişi istediğini yazabilir. Fakat Maked By Pasif Studio yazısını silmemelidir.

---------------------------------------------------------------------
# Node.js Back End Developer Discord : https://discord.gg/AJ2ntKtBWb