module.exports = {
  mailuser: "",
  mailpass: "",
  dbURL: "mongodb+srv://Groptoffen:grop88to@cluster0.cwuxt.mongodb.net/PasifCodeShare?retryWrites=true&w=majority",
  token: "OTMxODIzNzU0NTAwMjU5ODUw.YeKCfw.X4OtXjqNX2CsdygS9yQiZBAV3-A",
  admin: ('617bc6978a33db7fec81296f','616163733f208869307b4096','616158089a0ac0b2d4664c94'),
  secret: "1293837272727",
  kod_paylas: true, //Boolean
  //TİTLES
  mainTitle: "Ana Sayfa",
  iletisimTitle: "İletişim",
  title404: "Sayfa Bulunamadı",
  kurallarTitle: "Kurallar",
  adminPanelTitle: "Admin Panel",
  codeAddTitle: "Kod Ekle",
  altYapıAddTitle: "AltYapı Ekle",
  searchTitle: "Arama",
  //codes
  AoijsCodesTitle: "AoiJs Kodlar",
  HtmlCodesTitle: "HTML Kodlar",
  DiscordjsCodesTitle: "DiscordJS Kodlar",
  LuaCodesTitle: "Lua Kodları",
  //users
  dashboardTitle: "Gösterge Paneli",
  loginTitle: "Giriş Yap",
  registerTitle: "Kayıt Ol",
  //code add
  AoijsCodeAddTitle: "Aoijs Kodu Ekle",
  HtmlCodeAddTitle: "HTML Kodu Ekle",
  DiscordjsCodeAddTitle: "DiscordJS Kodu Ekle",
  LuaCodeAddTitle: "Lua Kodu Ekle",
  //code update
  AoijsCodeUpdateTitle: "Aoijs Kodunu Güncelle",
  HtmlCodeUpdateTitle: "HTML Kodunu Güncelle",
  DiscordJSCodeUpdateTitle: "DiscordJS Kodunu Güncelle",
  LuaCodeUpdateTitle: "Lua Kodunu Güncelle",
//dashboard codes
  AoijsCodesDashboardTitle: "Paylaştığın AoiJS Kodları",
  HtmlCodesDashboardTitle: "Paylaştığın HTML Kodları",
  DiscordjsCodesDashboardTitle: "Paylaştığın DiscordJS Kodları",
  LuaCodesDashboardTitle: "Paylaştığın Lua Kodları",
  //profil title
  profilTitle: "Profil",
  //ranks
  ranksTitle: "Kullanıcı"
}