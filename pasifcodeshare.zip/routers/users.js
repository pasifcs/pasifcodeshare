const express = require('express');
const router = express.Router();
const controller = require('../controller/users')
const dashController = require('../controller/dashboard')
const adminController = require('../controller/admin')
const postsController = require("../controller/posts")

router.get("/mail-verify/:user", controller.mail_verify)
router.post("/mail-verify/:user", controller.mail_verify_post)

//profil
router.get("/dashboard/profil", controller.profil)
router.post('/dashboard/profil/password-update', postsController.password_update)
router.post('/profil/avatar-update', postsController.avatar_update)

//admin
router.get('/admin/dashboard', adminController.admin_panel)
router.get('/admin/dashboard/aoijs-codes/onay=:onay', adminController.aoi)
router.get('/admin/dashboard/html-codes/onay=:onay', adminController.html)
router.get('/admin/dashboard/discordjs-codes/onay=:onay', adminController.discord)
router.get('/admin/dashboard/lua-codes/onay=:onay', adminController.lua)

//onayla
router.get("/moderator/aoijs-onayla/:id", adminController.aoijs_onay)
router.get("/moderator/html-onayla/:id", adminController.html_onay)
router.get("/moderator/discordjs-onayla/:id", adminController.discordjs_onay)
router.get("/moderator/lua-onayla/:id", adminController.lua_onay)

//dashboard
router.get('/dashboard/aoijs', dashController.aoi)
router.get('/dashboard/html', dashController.html)
router.get('/dashboard/discordjs', dashController.discord)
router.get('/dashboard/lua', dashController.lua)
router.get('/dashboard',controller.dashboard)

//login-register
router.get('/login',controller.login_get)
router.get('/register',controller.register_get)
router.get('/logout',controller.logout)
router.post('/posts/login',controller.login_post)
router.post('/posts/register',controller.register_post)

module.exports = router;