const express = require('express');
const router = express.Router();
const controller = require('../controller/main')
const dashController = require('../controller/dashboard')
const codeUpdateController = require('../controller/code-update')
const codeController = require('../controller/code')
const codeDeleteController = require('../controller/code-delete')
const adminController = require("../controller/admin")
const ranksController = require("../controller/ranks")
const altyapiController = require("../controller/altyapi")

router.get("/", controller.main)

//SİTE
router.get('/kurallar', controller.kurallar)
router.get("/iletisim", controller.iletisim)
router.get("/user/:userId", controller.user)
router.post("/search", controller.search)

//code delete
router.get('/aoijs-delete/:id', codeDeleteController.aoijs_delete)
router.get('/html-delete/:id', codeDeleteController.html_delete)
router.get('/discordjs-delete/:id', codeDeleteController.discordjs_delete)
router.get('/lua-delete/:id', codeDeleteController.lua_delete)

//Update
router.get('/aoijs-update/:id', codeUpdateController.aoijs_update_get)
router.post('/aoijs-update/:id', codeUpdateController.aoijs_update_post)
router.get('/html-update/:id', codeUpdateController.html_update_get)
router.post('/html-update/:id', codeUpdateController.html_update_post)
router.get('/discordjs-update/:id', codeUpdateController.discordjs_update_get)
router.post('/discordjs-update/:id', codeUpdateController.discordjs_update_post)
router.get('/lua-update/:id', codeUpdateController.lua_update_get)
router.post('/lua-update/:id', codeUpdateController.lua_update_post)

//code
router.get('/aoijs-code/:id', codeController.aoijs_code)
router.get('/html-code/:id', codeController.html_code)
router.get('/discordjs-code/:id', codeController.discordjs_code)
router.get("/lua-code/:id", codeController.lua_code)

//codes
router.get("/aoijs-codes", controller.aoijs_codes)
router.get("/html-codes", controller.html_codes)
router.get("/discordjs-codes", controller.discordjs_codes)
router.get("/lua-codes", controller.lua_codes)

//add
router.get("/aoijs-add", controller.aoi_add)
router.get("/html-add", controller.html_add)
router.get("/discordjs-add", controller.discord_add)
router.get("/lua-add", controller.lua_add)

//Ranks
router.get("/dashboard/kurucu-panel", ranksController.kurucu_panel)
router.get("/dashboard/yetkili-panel", ranksController.yetkili_panel)
router.get("/dashboard/moderator-panel", ranksController.moderator_panel)
router.get("/dashboard/yetkili-user/:username", ranksController.ranks)
router.post("/dashboard/rank-update/:id", ranksController.rank_update)

//Like
router.get("/aoijs-like", codeController.aoijs_like)
router.get("/html-like", codeController.html_like)
router.get("/discordjs-like", codeController.discordjs_like)
router.get("/lua-like", codeController.lua_like)

//Askıya alma
router.get("/askiya-aoijs/:title", codeDeleteController.askiya_aoijs);
router.get("/askiya-html/:title", codeDeleteController.askiya_html);
router.get("/askiya-discordjs/:title", codeDeleteController.askiya_discordjs);
router.get("/askiya-lua/:title", codeDeleteController.askiya_lua);

//AltYapı
router.get("/altyapi-ekle", altyapiController.add)
router.post("/altyapi-ekle", altyapiController.add_post)
router.get("/altyapilar", altyapiController.altyapilar)
router.get("/altyapi", altyapiController.altyapi)

module.exports = router;