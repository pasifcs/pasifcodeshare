const express = require('express');
const router = express.Router();
const controller = require('../controller/posts')

router.post('/aoi-add', controller.aoi_add)
router.post('/html-add', controller.html_add)
router.post('/discord-add', controller.discord_add)
router.post('/lua-add', controller.lua_add)

module.exports = router;
  