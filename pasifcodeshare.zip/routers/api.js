const express = require("express");
const router = express.Router();
const Users = require("../models/users");
const Aoijs = require("../models/aoijs-codes");
const Djs = require("../models/discordjs-codes");
const Html = require("../models/html-codes");
const Lua = require("../models/lua-codes");

router.get("/code-count", (req,res)=>{
//total
   Aoijs.find({}, function(err,taoijs){
  Djs.find({}, function(err,tdjs){
 Html.find({}, function(err,thtml){
Lua.find({}, function(err,tlua){
//onaylanmış  
 Aoijs.find({onay: true}, function(err,traoijs){
  Djs.find({onay: true}, function(err,trdjs){
 Html.find({onay: true}, function(err,trhtml){
Lua.find({onay: true}, function(err,trlua){
 //onaylanmamış 
 Aoijs.find({onay: false}, function(err,fsaoijs){
  Djs.find({onay: false}, function(err,fsdjs){
 Html.find({onay: false}, function(err,fshtml){
Lua.find({onay: false}, function(err,fslua){
  res.json({
    total: {
      aoijs: taoijs.length,
      djs: tdjs.length,
      html: thtml.length,
      lua: tlua.length
    },
    onaylanmis: {
      aoijs: traoijs.length,
      djs: trdjs.length,
      html: trhtml.length,
      lua: trlua.length
    },
    onaylanmamis: {     
      aoijs: fsaoijs.length,
      djs: fsdjs.length,
      html: fshtml.length,
      lua: fslua.length
    }
  })
})})})})
})})})})
})})})})  
})

module.exports = router;