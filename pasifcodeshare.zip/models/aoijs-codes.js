const mongoose = require('mongoose');
const aoiSchema = new mongoose.Schema({
  title: {
    type: String,
    require: true,
    unique: true
  },
  description: {
    type: String,
    require: true
  },
  code: {
    type: String,
    require: true
  },
  sahip: {
    type: String,
    require: true
  },
  onay: {
    type: Boolean,
    require: true
  },
  durum: {
    type: String,
    require: true
  },
  likeatanlar: Array,
  like: String
}, {timestamps: true});

module.exports = mongoose.model('AoiJS', aoiSchema);