const mongoose = require("mongoose");
const altyapiSchema = new mongoose.Schema({
  title: {
    type: String,
    require: true,
    unique: true
  },
  description: String,
  link: {
    type: String,
    unique: true
  },
  kategori: String,
  ozel: Boolean,
  sahip: String
}, {timestamps: true});

module.exports = mongoose.model("AltYapılar", altyapiSchema)